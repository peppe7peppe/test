const users = []; // går även bra med databas, men nu använder jag en array

// Anslut användare till chat
function userJoin(id, username, room) {
    const user = { id, username, room };

    users.push(user);

    return user;
}

//Hämta nuvarande användare
function getCurrentUser(id){
    return users.find(user => user.id === id);
}

// Användare lämnar chat
function userLeave(id){
    const index = users.findIndex(user => user.id === id);
    if(index !== -1) {
        return users.splice(index, 1)[0];
    }
}

//Hämta rum användare
function getRoomUsers(room){return users.filter(user => user.room === room);}

//Exportera funktioner
module.exports = {
    userJoin,
    getCurrentUser,
    userLeave,
    getRoomUsers
};